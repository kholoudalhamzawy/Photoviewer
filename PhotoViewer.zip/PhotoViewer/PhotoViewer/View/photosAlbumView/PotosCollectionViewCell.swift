//
//  PotosCollectionViewCell.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 16/02/2025.
//

import UIKit
import Kingfisher

class PotosCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var albumPhoto: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configure(with photo: Photo) {
        if let url = URL(string: photo.thumbnailUrl) {
            albumPhoto.tintColor = .gray
            albumPhoto.kf.setImage(
                     with: url,
                     placeholder: UIImage(systemName: "photo"),
                     options: [
                         .transition(.fade(0.2)),
                         .cacheOriginalImage
                     ]
                 )
             }
    }

}
