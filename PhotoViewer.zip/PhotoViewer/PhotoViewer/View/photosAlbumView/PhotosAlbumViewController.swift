//
//  PhotosAlbumViewController.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 09/02/2025.
//

import UIKit
import Combine

class PhotosAlbumViewController: UIViewController {
    
    @IBOutlet weak var photosCollectionView: UICollectionView!{
        didSet {
            setupCollectionView()
        }
    }
    private var albumId: Int
    private var albumTitle: String
    
    private var cancellables = Set<AnyCancellable>()
    lazy private var viewModel: AlbumViewModel = {
        
        let apiService = APIService()
        let fetchPhotosUseCase = FetchPhotosUseCase(apiService: apiService)
        let albumViewModel = AlbumViewModel(fetchPhotosUseCase: fetchPhotosUseCase, albumId: self.albumId, title: self.albumTitle)
        return albumViewModel
        
    }()
    
    init(albumId: Int, title: String) {
        self.albumId = albumId
        self.albumTitle = title
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        bindViewModel()
        configureCollectionViewLayout()
    }
    
}

// MARK: - configuration
extension PhotosAlbumViewController {
    
    func setupCollectionView() {
        photosCollectionView.register(UINib(nibName: "PotosCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "PotosCollectionViewCell")
        photosCollectionView.delegate = self
        photosCollectionView.dataSource = self
        let nib = UINib(nibName: "photosCollectionViewHeader", bundle: nil)
        photosCollectionView.register(nib, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "photosCollectionViewHeader")
        
    }
    
    private func configureCollectionViewLayout() {
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumInteritemSpacing =  CGFloat.leastNormalMagnitude
        layout.minimumLineSpacing = CGFloat.leastNormalMagnitude
        layout.sectionInset = .zero
        let itemsPerRow: CGFloat = 3
        let itemWidth = view.frame.width / itemsPerRow
        
        layout.itemSize = CGSize(width: itemWidth, height: itemWidth)
        
        photosCollectionView.collectionViewLayout = layout
        
    }
    
    private func bindViewModel() {
        viewModel.$filteredPhotos
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.photosCollectionView.reloadData()
            }
            .store(in: &cancellables)
        
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource

extension PhotosAlbumViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.filteredPhotos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PotosCollectionViewCell", for: indexPath) as? PotosCollectionViewCell else {
            return UICollectionViewCell()
        }
        
        let photo = viewModel.filteredPhotos[indexPath.row]
        cell.configure(with: photo)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        openImageViewer(with: viewModel.filteredPhotos[indexPath.row])
    }
    
    func openImageViewer(with photo: Photo) {
        let imageViewer = ImageViewerViewController()
        imageViewer.image = photo
        imageViewer.modalPresentationStyle = .pageSheet
        present(imageViewer, animated: true)
    }
}

// MARK: - UICollectionViewDelegateFlowLayout

extension PhotosAlbumViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        if kind == UICollectionView.elementKindSectionHeader {
            let header = collectionView.dequeueReusableSupplementaryView( ofKind: kind, withReuseIdentifier: "photosCollectionViewHeader", for: indexPath) as! photosCollectionViewHeader
            header.nameLbl.text = viewModel.title
            header.configureSearchBar(delegate: self)
            return header
        }
        return UICollectionReusableView()
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: collectionView.bounds.width, height: 110)
    }
}

// MARK: - photosCollectionViewHeaderDelegate

extension PhotosAlbumViewController: photosCollectionViewHeaderDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
   
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.searchQuery = searchText
    }
    
}
