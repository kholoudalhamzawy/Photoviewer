//
//  photosCollectionViewHeader.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 09/02/2025.
//

import UIKit

class photosCollectionViewHeader: UICollectionReusableView {
    @IBOutlet weak var nameLbl: UILabel!
    
    @IBOutlet weak var searchBar: UISearchBar!
    private var searchBarDelegate: photosCollectionViewHeaderDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
    }
    func configureSearchBar(delegate: photosCollectionViewHeaderDelegate){
        searchBar.delegate = delegate
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }

}

protocol photosCollectionViewHeaderDelegate: UISearchBarDelegate {
    
}
