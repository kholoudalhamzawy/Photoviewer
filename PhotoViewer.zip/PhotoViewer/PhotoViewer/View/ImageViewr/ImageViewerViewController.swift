//
//  ImageViewerViewController.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 17/02/2025.
//

import UIKit

class ImageViewerViewController: UIViewController {
    @IBOutlet weak var viewerScrollView: UIScrollView!
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var shareBtn: UIButton!
    var image: Photo?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configure(with: image)
        configureScrollView()
    }
    
    func configure(with photo: Photo?) {
        if let photo = photo, let url = URL(string: photo.thumbnailUrl) {
            imageView.kf.setImage(
                with: url,
                placeholder: UIImage(systemName: "photo"),
                options: [
                    .transition(.fade(0.2)),
                    .cacheOriginalImage
                ]
            )
            
        }
        
    }
    @IBAction func didTapShare(_ sender: Any) {
        guard let image = imageView else { return }
        let activityController = UIActivityViewController(activityItems: [image], applicationActivities: nil)
        present(activityController, animated: true)
    }
}


extension ImageViewerViewController: UIScrollViewDelegate {
    
    func configureScrollView(){
        viewerScrollView.delegate = self
        viewerScrollView.minimumZoomScale = 1.0
        viewerScrollView.maximumZoomScale = 5.0
        viewerScrollView.zoomScale = 1.0
    }
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imageView
    }
    
    func scrollViewDidEndZooming(_ scrollView: UIScrollView, with view: UIView?, atScale scale: CGFloat) {
        if scale != viewerScrollView.minimumZoomScale {
            viewerScrollView.setZoomScale(viewerScrollView.minimumZoomScale, animated: true)
        }
    }
    
}
