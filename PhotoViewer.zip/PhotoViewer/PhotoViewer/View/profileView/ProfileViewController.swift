//
//  ViewController.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 09/02/2025.
//

import UIKit
import Combine

class ProfileViewController: UIViewController {
    
    @IBOutlet weak var albumsTableView: UITableView!
    
    var customHeaderView: ProfileTableViewHeaderView!
    
    var viewModel: ProfileViewModel = {
        let apiService = APIService()
        let fetchUserUseCase = FetchUserUseCase(apiService: apiService)
        let fetchAlbumsUseCase = FetchAlbumsUseCase(apiService: apiService)
        let viewModel = ProfileViewModel(fetchUserUseCase: fetchUserUseCase, fetchAlbumsUseCase: fetchAlbumsUseCase)
        
        return viewModel
        
    }()
    
    private var cancellables = Set<AnyCancellable>()
    private var activityIndicator: UIActivityIndicatorView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpUI()
        setUpLoader()
        bindViewModel()
    }
    
    
}

// MARK: - configuration
extension ProfileViewController {
    
    private func setUpUI() {
        albumsTableView.delegate = self
        albumsTableView.dataSource = self
        albumsTableView.register(UINib(nibName: "AlbumTableViewCell", bundle: nil), forCellReuseIdentifier: "AlbumTableViewCell")
        albumsTableView.rowHeight = UITableView.automaticDimension
        albumsTableView.estimatedRowHeight = 130
        
        customHeaderView = Bundle.main.loadNibNamed("ProfileTableViewHeaderView", owner: nil, options: nil)?.first as? ProfileTableViewHeaderView
        albumsTableView.tableHeaderView = customHeaderView
        navigationController?.navigationBar.tintColor = UIColor.black
        
    }
    
    private func setUpLoader() {
        activityIndicator = UIActivityIndicatorView(style: .large)
        activityIndicator.center = view.center
        activityIndicator.hidesWhenStopped = true
        view.addSubview(activityIndicator)
    }
    
    private func handleLoadingState(_ isLoading: Bool) {
        isLoading ? startAnimating() : stopAnimating()
    }
    
    private func startAnimating() {
        activityIndicator.startAnimating()
        view.isUserInteractionEnabled = false
    }
    
    private func stopAnimating() {
        activityIndicator.stopAnimating()
        view.isUserInteractionEnabled = true
    }
    
    private func showErrorMessage(_ errorMessage: String?) {
        guard let errorMessage = errorMessage, !errorMessage.isEmpty else { return }
        showAlertMessage(title: "Error", message: errorMessage) {
            self.navigationController?.popViewController(animated: true)
        }
    }
}

// MARK: - Binding
extension ProfileViewController {

    
    private func bindViewModel() {
        viewModel.$isLoading
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isLoading in
                self?.handleLoadingState(isLoading)
            }
            .store(in: &cancellables)

        viewModel.$user
            .receive(on: DispatchQueue.main)
            .sink { [weak self] user in
                self?.customHeaderView.configure(with: user)
            }
            .store(in: &cancellables)

        viewModel.$albums
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.albumsTableView.reloadData()
            }
            .store(in: &cancellables)

        viewModel.$errorMessage
            .receive(on: DispatchQueue.main)
            .sink { [weak self] errorMessage in
                self?.showErrorMessage(errorMessage)
            }
            .store(in: &cancellables)
    }
    
  
}

// MARK: - UITableViewDelegate, UITableViewDataSource

extension ProfileViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.albums.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "AlbumTableViewCell", for: indexPath) as? AlbumTableViewCell else {
            return UITableViewCell()
        }
        let album = viewModel.albums[indexPath.row]
        cell.configure(with: album)
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let album = viewModel.albums[indexPath.row]
        
        let albumVC = PhotosAlbumViewController(albumId: album.id, title: album.title)
        navigationController?.pushViewController(albumVC, animated: true)
    }
}
