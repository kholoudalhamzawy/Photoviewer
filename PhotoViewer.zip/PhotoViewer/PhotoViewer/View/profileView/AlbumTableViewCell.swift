//
//  AlbumTableViewCell.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 12/02/2025.
//

import UIKit

class AlbumTableViewCell: UITableViewCell {


    @IBOutlet weak var nameLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configure(with album: Album) {
        nameLabel.text = album.title
       }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
