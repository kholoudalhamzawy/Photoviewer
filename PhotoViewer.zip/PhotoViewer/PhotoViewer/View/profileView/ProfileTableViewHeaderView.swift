//
//  ProfileTableViewHeaderView.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 09/02/2025.
//

import UIKit

class ProfileTableViewHeaderView: UIView {
    @IBOutlet weak var profileLbl: UILabel!
    
    @IBOutlet weak var myAlbumsLbl: UILabel!
    @IBOutlet weak var adressLbl: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
  
    func configure(with user: User?) {
        nameLbl.text = user?.name ?? "Unknown"
        adressLbl.text = user?.email ?? "No Address Available"
       }
}
