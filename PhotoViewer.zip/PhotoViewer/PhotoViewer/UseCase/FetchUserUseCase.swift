//
//  FetchUserUseCase.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 11/02/2025.
//

import Foundation
import Combine

protocol FetchUserUseCaseProtocol {
    func execute() -> AnyPublisher<User, Error>
}

class FetchUserUseCase: FetchUserUseCaseProtocol {
    private let apiService: APIServiceProtocol

    init(apiService: APIServiceProtocol) {
        self.apiService = apiService
    }

    func execute() -> AnyPublisher<User, Error> {
        return apiService.fetchUser()
            .compactMap { $0.randomElement() }
            .eraseToAnyPublisher()
    }
}
