//
//  Album.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 14/02/2025.
//

import Foundation

struct Album: Codable {
    let userId: Int
    let id: Int
    let title: String
}
