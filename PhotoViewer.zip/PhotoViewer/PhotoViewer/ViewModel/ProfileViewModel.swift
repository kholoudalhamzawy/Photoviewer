//
//  ProfileViewModel.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 11/02/2025.
//

import Foundation
import Combine

class ProfileViewModel: ObservableObject {
    @Published var user: User?
    @Published var albums: [Album] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    private let fetchUserUseCase: FetchUserUseCaseProtocol
    private let fetchAlbumsUseCase: FetchAlbumsUseCaseProtocol
    private var cancellables = Set<AnyCancellable>()

    init(fetchUserUseCase: FetchUserUseCaseProtocol, fetchAlbumsUseCase: FetchAlbumsUseCaseProtocol) {
        self.fetchUserUseCase = fetchUserUseCase
        self.fetchAlbumsUseCase = fetchAlbumsUseCase
        fetchUser()
    }

    func fetchUser() {
        isLoading = true
        fetchUserUseCase.execute()
            .sink(receiveCompletion: { completion in
                self.isLoading = false
                if case .failure(let error) = completion {
                    self.errorMessage = error.localizedDescription
                }
            }, receiveValue: { user in
                self.user = user
                self.fetchAlbums(for: user.id)
            })
            .store(in: &cancellables)
    }

    func fetchAlbums(for userId: Int) {
        fetchAlbumsUseCase.execute(userId: userId)
            .sink(receiveCompletion: { completion in
                if case .failure(let error) = completion {
                    self.errorMessage = error.localizedDescription
                }
            }, receiveValue: { albums in
                self.albums = albums
            })
            .store(in: &cancellables)
    }
}

