//
//  APIService.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 11/02/2025.
//

import Moya
import Combine
import CombineMoya

protocol APIServiceProtocol {
    func fetchUser() -> AnyPublisher<[User], Error>
    func fetchAlbums(userId: Int) -> AnyPublisher<[Album], Error>
    func fetchPhotos(albumId: Int) -> AnyPublisher<[Photo], Error>
}

class APIService: APIServiceProtocol {
    private let provider = MoyaProvider<APIProvider>()

    func fetchUser() -> AnyPublisher<[User], Error> {
        provider.requestPublisher(.getUser)
            .map([User].self)
            .mapError { $0 as Error }
            .eraseToAnyPublisher()
    }
    
    func fetchAlbums(userId: Int) -> AnyPublisher<[Album], Error> {
        provider.requestPublisher(.getAlbums(userId: userId))
            .map([Album].self)
            .mapError { $0 as Error }
            .eraseToAnyPublisher()
    }
    
    func fetchPhotos(albumId: Int) -> AnyPublisher<[Photo], Error> {
        provider.requestPublisher(.getPhotos(albumId: albumId))
            .map([Photo].self)
            .mapError { $0 as Error }
            .eraseToAnyPublisher()
    }
}
