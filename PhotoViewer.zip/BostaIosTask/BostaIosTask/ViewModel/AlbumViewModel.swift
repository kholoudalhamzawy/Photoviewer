//
//  AlbumViewModel.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 11/02/2025.
//

import Foundation
import Combine

class AlbumViewModel: ObservableObject {
    @Published var photos: [Photo] = []
    @Published var filteredPhotos: [Photo] = []
    @Published var searchQuery = ""
    @Published var title = ""

    private let fetchPhotosUseCase: FetchPhotosUseCaseProtocol
    private var cancellables = Set<AnyCancellable>()

    init(fetchPhotosUseCase: FetchPhotosUseCaseProtocol, albumId: Int, title: String) {
        self.fetchPhotosUseCase = fetchPhotosUseCase
        self.title = title
        fetchPhotos(albumId: albumId)
        setupSearch()
    }

    private func fetchPhotos(albumId: Int) {
        fetchPhotosUseCase.execute(albumId: albumId)
            .sink(receiveCompletion: { _ in }, receiveValue: { photos in
                self.photos = photos
                self.filteredPhotos = photos
            })
            .store(in: &cancellables)
    }

    private func setupSearch() {
        $searchQuery
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
            .sink { query in
                self.filteredPhotos = query.isEmpty ? self.photos : self.photos.filter { $0.title.lowercased().contains(query.lowercased()) }
            }
            .store(in: &cancellables)
    }
}
