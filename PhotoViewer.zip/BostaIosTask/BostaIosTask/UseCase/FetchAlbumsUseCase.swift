//
//  FetchAlbumsUseCase.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 11/02/2025.
//

import Foundation
import Combine

protocol FetchAlbumsUseCaseProtocol {
    func execute(userId: Int) -> AnyPublisher<[Album], Error>
}

class FetchAlbumsUseCase: FetchAlbumsUseCaseProtocol {
    private let apiService: APIServiceProtocol

    init(apiService: APIServiceProtocol) {
        self.apiService = apiService
    }

    func execute(userId: Int) -> AnyPublisher<[Album], Error> {
        return apiService.fetchAlbums(userId: userId)
    }
}
