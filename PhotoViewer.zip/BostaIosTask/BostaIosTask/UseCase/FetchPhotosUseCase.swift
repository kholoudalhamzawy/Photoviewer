//
//  FetchPhotosUseCase.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 11/02/2025.
//

import Foundation
import Combine

protocol FetchPhotosUseCaseProtocol {
    func execute(albumId: Int) -> AnyPublisher<[Photo], Error>
}

class FetchPhotosUseCase: FetchPhotosUseCaseProtocol {
    private let apiService: APIServiceProtocol

    init(apiService: APIServiceProtocol) {
        self.apiService = apiService
    }

    func execute(albumId: Int) -> AnyPublisher<[Photo], Error> {
        return apiService.fetchPhotos(albumId: albumId)
    }
}
