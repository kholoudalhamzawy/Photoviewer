//
//  UIViewController+Extentions.swift
//  BostaIosTask
//
//  Created by kholoud alhamzawy on 12/02/2025.
//

import UIKit


extension UIViewController {
    func showAlertMessage(title: String, message: String, completion: (() -> Void)? = nil) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            completion?()
        }
        
        alertController.addAction(okAction)
        
        DispatchQueue.main.async {
            self.present(alertController, animated: true, completion: nil)
        }
    }
}


